# Smart Playlists & MIDI Library Management

[← Home](Home)

## Separate libraries for Solo and Ensemble

Windbound keeps distinct **Solo** and **Ensemble** playlist profiles. Changing the Ensemble role/library saves the current playlist and restores the appropriate one. A named playlist stores its own song order and Smart Playlist settings.

In **Songs & Playback** you can:

1. Click **Add MIDI files…** or **Add MIDI folder…** to populate a playlist.
2. Choose **Solo library** or **Ensemble library**.
3. Use **Create playlist** to make a new named profile; choose whether to copy the current songs.
4. Use **Rename**, **Save playlist**, **Export playlist JSON** or **Import playlist JSON** to manage backups.

### Search, favourites and tags

Use the Smart Playlist Manager's search to filter by filename, path or custom tag. Toggle **Favourites only**, or assign comma-separated tags such as `duet, piano, classic`. Favourites and tags are scoped to the saved playlist and are included when exporting a playlist JSON file.

### Drag-and-drop ordering

Drag a song row onto another to change order. Alternatively right-click a song for **Move one place up/down**, **Play NEXT**, **Add to favourites**, or **Remove from playlist**. Removing a playlist entry **does not delete the actual MIDI file**.

### Play Next, shuffle and repeat

- **Play NEXT** adds a song to a separate request queue. It does **not** rearrange the main playlist.
- **Shuffle** draws from a no-repeat cycle, subject to the currently prepared song and repeat mode.
- **Repeat Off** stops at the end; **Repeat All** wraps/restarts; **Repeat One** repeats the current track after completion.
- Manual **Next** bypasses Repeat One, while queued songs take priority over the ordinary order.
- **Auto next** works for **Solo** playback; ensemble song transitions remain controlled by the conductor.

### Recent songs

The recently played panel keeps up to 50 recent starts per playlist profile (the UI shows the latest 20). You can use the panel to reload a familiar MIDI.

### Missing file cleanup

Click **Scan for missing files**, review the missing entries and confirm removal. This deletes broken **playlist references only**. Your MIDI files on disk remain untouched.

## Recommended concert-library structure

Consider separate profiles such as:

| Playlist | Purpose |
|---|---|
| `Nunu - Solo Piano` | Personal practice / live keyboard pieces |
| `Nunu & Edea - Duets` | Two-Bard concert order |
| `Full Octet - Main Set` | Eight-player concert with saved lineup |
| `Full Octet - Encores` | Optional requested songs |

A Song Playlist JSON export stores paths and metadata but **not the underlying MIDI bytes**. On another PC, make sure those files exist at the paths expected by the receiving client, or import the same songs into its local library.

**Next:** [[Concert Director|Concert-Director-and-Setlists]] · [[Concert Snapshots|Concert-Snapshots-and-Restore]]
