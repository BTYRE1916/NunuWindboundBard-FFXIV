# Octet Concert Checklist — Print This Before a Show

[← Home](Home)

Use this as a quick pre-concert checklist for an eight-character native ensemble. It can also be adapted for duets, quartets and other party sizes.

## Before opening the venue

- [ ] All clients have a known-working **Windbound version** and compatible Dalamud.
- [ ] Every Bard has the same MIDI files in its local library (not necessarily the same path).
- [ ] All accounts are in the **same FFXIV party**; conductor is the actual party leader.
- [ ] All eight performers use **expanded 37-note Performance** and the correct key mapping.
- [ ] Follower options: native Game Ensemble, leader sync, **Auto-Accept**, and **Allow leader ARM** (if desired).
- [ ] Stage movement is complete and stopped; optional vnavmesh is idle.
- [ ] Each instrument can be equipped locally; no switching state is stuck.
- [ ] Latest MIDI and Concert Snapshot backups exist.

## Five conductor buttons, in order

| Step | Button | Expected result |
|---:|---|---|
| 1 | **SYNC SELECTED MIDI TO PARTY** | Everyone loads the same MIDI fingerprint |
| 2 | **SET PARTY TRACKS** | Each Bard keeps only its assigned part(s) |
| 3 | **SET PARTY INSTRUMENTS** | Everyone equips the requested Performance instrument |
| 4 | **ARM ALL BARDS** | Seven followers acknowledge ARM; keyboard readiness confirmed |
| 5 | **START ENSEMBLE** | FFXIV native Ready Check synchronises the actual note start |

**Shortcut:** **PREPARE ENTIRE ORCHESTRA** combines the preparation/status process. Check Stage Manager readiness and the group ARM state before START.

## During the show

- Keep the **Conductor HUD** visible. Watch song progress and READY/failure alerts.
- If a Bard doesn't respond, use **Retry** for that member instead of resetting everyone.
- If preparing the next song automatically, remember it **never auto-starts**: the conductor must send the next native Ensemble START.
- Use **HOLD after this song** when speaking to the audience or rearranging performers.
- Do not click a local follower Play button or rewind only one client during a synchronised song.

## End the performance

1. Press **STOP ENSEMBLE + UNEQUIP ALL** on the conductor.
2. Confirm held notes stop and instruments are put away; note that a native stow can fail if the game refuses it.
3. If leaving the stage, stop vnavmesh/stage movement before starting another song.
4. Save or export the final Concert Snapshot and playlist as a backup.

## Emergency card

| If… | Do this |
|---|---|
| Player says “already running” | `/windbound recover` on the affected local client; ARM again |
| MIDI advances but no notes | Verify **ARM + 37-key keyboard + instrument + assigned tracks** |
| Conductor commands reach only some Bards | Copy **Party command receiver diagnostics** from a silent follower |
| A performer is missing | **Concert Director → Retry** only that Bard |
| Native Ready Check fails | Check readiness, Auto-Accept and FFXIV game status; don't use retired chat timer |
| Stage dots don't move | Stop movement; verify vnavmesh, party permission, housing ward and walkable destination |

**More detail:** [[Conductor & Octets|Conductor-and-Octet-Operations]] · [[Concert Director|Concert-Director-and-Setlists]] · [[Troubleshooting|Troubleshooting]]
