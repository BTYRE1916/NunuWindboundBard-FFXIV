# Languages & Localisation

[← Home](Home)

Windbound v0.32 provides **English**, **French (Français)** and **German (Deutsch)** UI options.

## Change language

1. Open `/windbound`.
2. At the top of the main window, locate **Interface language**.
3. Select **English**, **Français**, or **Deutsch**.
4. The UI changes immediately, and the selected language is saved for that client. A restart is not required.

The language setting affects interface labels, buttons, hints, tab names, most status messages, the performance HUD, concert/snapshot features and Stage Formations. Filenames, arbitrary MIDI track names, party-chat protocol commands and third-party driver/game errors may remain in their original language.

## Examples of key controls

| English | Français | Deutsch |
|---|---|---|
| Songs & Playback | Morceaux et lecture | Songs & Wiedergabe |
| Stage Formations | Formations de scène | Bühnenformationen |
| Concert Snapshots | Instantanés de concert | Konzert-Schnappschüsse |
| Audio Preview | Aperçu audio | Audiovorschau |

UI labels can vary slightly depending on the installed translation build; the underlying functions do not change.

## Help improve translations

The v0.32 source package includes **`GERMAN-TRANSLATIONS.tsv`**, intended for reviewers to flag grammar, truncation, tone and musical vocabulary. A useful beta report contains: language, exact tab/control, current wording, suggested wording, source version, and screenshot where possible.

Do not translate `##` suffixes in C#/ImGui UI control identifiers or literal MIDI filename/tag syntax. The UI uses those IDs internally, so changing them can break widget state even when the displayed text looks correct.

## Translation compatibility

Language selection is local to each Bard: a German-speaking Follower and an English-speaking Conductor can participate in the same native ensemble. MIDI data, note mapping, hashes and assignment messages do not change with the interface language.

**Next:** [[Beta Testing|Build-Beta-Testing-and-Updates]] · [[FAQ|Frequently-Asked-Questions]]
