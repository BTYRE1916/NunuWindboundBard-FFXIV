# Conductor Controls & Octet Operations

[← Home](Home)

This chapter is for anyone running a duet, quartet, octet, or multiple game clients on one PC. All preparation commands use Windbound's party-leader coordination; **the FFXIV native Ready Check remains the only start trigger**.

## Roles and prerequisites

- **Solo:** plays locally; has no conductor role.
- **Conductor:** chooses the ensemble's MIDI, performer assignments and instruments. Must be the **actual leader of the FFXIV party** for leader commands to be accepted.
- **Follower:** accepts matching file/track/instrument/ARM messages and waits for the native ensemble start.

All performers need the same MIDI bytes locally, a compatible Windbound version, and expanded Performance. Give each character enough time for instrument switching before START.

## Assigning performers to tracks

1. Load an Ensemble MIDI into the conductor's active playlist.
2. Open **Ensemble** → **Party-Roster Track Assignments**.
3. For each **Track / Channel**, select the Bard who should play its notes. Choose **Unassigned / silent** for unused parts.
4. Click **SET PARTY TRACKS — send to every Bard**.
5. Wait for **Tracks: READY** acknowledgements. A follower with no assigned notes may correctly be **silent**; that is not automatically an error.

### Keep your assignments across songs

Enable **Keep party track assignments across songs** (on by default in recent builds). The saved **lineup slots** carry to the next song in the same Ensemble playlist; per-song overrides can still take precedence. Use **Save current as default lineup**, **Apply saved lineup to this MIDI**, and **Forget saved lineup** as needed. New MIDI tracks that exceed the saved lineup need checking.

**Best practice:** If a special song uses a different performer arrangement, temporarily turn reuse off, edit that song, then re-enable reuse. The master lineup is not replaced unless you explicitly save it.

## Set Party Instruments

Under **Conductor File + Instrument Sync**, pick an instrument for each party member. Press **SET PARTY INSTRUMENTS — auto-switch everyone**. Followers automatically use the game's Performance instrument switching and report READY/failure. If **MIDI Instruments & Octave Tags** is enabled, detected instrument suggestions can be used unless you saved a manual instrument choice for this MIDI.

If a player has multiple parts requiring different instruments, choose a sensible main instrument for that character or split the parts among Bards. One Bard cannot simultaneously hold Piano and Violin.

## Set Party MIDI

Selecting an Ensemble song can automatically tell followers to load the matching MIDI. **SYNC SELECTED MIDI TO PARTY** resends the file-selection command when necessary. The file is looked up by identity/fingerprint; a same-named MIDI with different bytes is **not** necessarily a match.

## ARM ALL / DISARM ALL

**ARM ALL BARDS** arms the conductor and the opted-in followers. It never starts notes or equips instruments. Look for a response count such as `7/7 acknowledged` in an eight-character group. A follower may be ARMed but still show **37-key keyboard needed**; prepare the instrument before starting.

**DISARM ALL** revokes ARM; the instruments can stay equipped. ARM state is deliberately not saved across restart. Follower opt-in is controlled separately by **Allow my party leader to ARM this Bard automatically**.

## Recommended conductor sequence

```text
Choose Ensemble playlist and MIDI
            ↓
Assign / reuse performer slots
            ↓
SYNC SELECTED MIDI → SET PARTY TRACKS
            ↓
SET PARTY INSTRUMENTS (or PREPARE ENTIRE ORCHESTRA)
            ↓
ARM ALL BARDS → check READY status
            ↓
START ENSEMBLE — native FFXIV Ready Check
            ↓
STOP ENSEMBLE + UNEQUIP ALL at the end
```

## Same-PC eight-account setup

Running many game clients does **not** require eight Windows keystroke bots; Windbound's notes use direct Performance callbacks. Give each client the right **Follower** setting and 37-key Performance layout, keep the MIDI library available per account, and verify the correct client name appears in the compact HUD. The conductor's stage readiness panel helps identify a missed client without focusing each window.

## When only one client responds

1. Confirm every client runs the **same plugin version**.
2. Confirm **Conductor** is the real in-game party leader and the other accounts are **Follower**.
3. Inspect the Follower **Party command receiver diagnostics** for *messages seen*, *accepted*, and *rejected*.
4. Verify the MIDI fingerprint and party roster are the same.
5. Try **SYNC SELECTED MIDI**, **SET PARTY TRACKS**, **SET PARTY INSTRUMENTS** separately.
6. If a client doesn't equip, test the **Instruments** tab locally. Its issue may be native Performance readiness rather than party messaging.

**Next:** [[Concert Director|Concert-Director-and-Setlists]] · [[Troubleshooting|Troubleshooting]]
