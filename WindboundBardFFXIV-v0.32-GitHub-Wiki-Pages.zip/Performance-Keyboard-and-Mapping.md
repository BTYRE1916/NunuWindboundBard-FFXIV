# FFXIV Performance Keyboard & 37-Key Mapping

[← Home](Home)

**This is the most important setup step.** If FFXIV is set to a reduced/mini keyboard or to different bindings, a MIDI can appear to progress while no correct notes are heard.

## Set FFXIV to expanded Performance

1. Enter Bard Performance mode in FFXIV with a Performance instrument.
2. Use the **expanded/full keyboard** (37 notes), not the mini keyboard.
3. In FFXIV's Performance keyboard settings, configure the 37 keys in **chromatic pitch order** using the mapping below.
4. Open `/windbound` → **Direct Output & Test**. The window should say **Expanded Performance addon detected** or **FULL 37-KEY READY**.
5. Tick **ARM** in Songs & Playback and use **Test C4 (only when armed)** to verify output.

Windbound uses the Performance addon's native callbacks, not simulated Windows keypresses. The mapping is still valuable as a reference and must match the game's full layout for players also using normal keyboard Performance controls.

## Default 37-note binding table

The supplied `PerformanceKeyMap.DefaultKeys` is exactly:

```text
ZXCVBNMASDFGHJKLQWERTYUIOP1234567890;
```

| MIDI | Note | Key | MIDI | Note | Key | MIDI | Note | Key |
|---:|---|:---:|---:|---|:---:|---:|---|:---:|
| 48 | C3 | Z | 61 | C♯4 | J | 74 | D5 | 1 |
| 49 | C♯3 | X | 62 | D4 | K | 75 | D♯5 | 2 |
| 50 | D3 | C | 63 | D♯4 | L | 76 | E5 | 3 |
| 51 | D♯3 | V | 64 | E4 | Q | 77 | F5 | 4 |
| 52 | E3 | B | 65 | F4 | W | 78 | F♯5 | 5 |
| 53 | F3 | N | 66 | F♯4 | E | 79 | G5 | 6 |
| 54 | F♯3 | M | 67 | G4 | R | 80 | G♯5 | 7 |
| 55 | G3 | A | 68 | G♯4 | T | 81 | A5 | 8 |
| 56 | G♯3 | S | 69 | A4 | Y | 82 | A♯5 | 9 |
| 57 | A3 | D | 70 | A♯4 | U | 83 | B5 | 0 |
| 58 | A♯3 | F | 71 | B4 | I | 84 | C6 | ; |
| 59 | B3 | G | 72 | C5 | O | | | |
| 60 | C4 | H | 73 | C♯5 | P | | | |

The range is **MIDI 48 through 84 inclusive**, C3 to C6. This is 37 chromatic notes, not 37 white piano keys.

## Why the note range matters

A concert MIDI may contain notes below C3 or above C6. Windbound's **FFXIV Optimiser** can shift parts by octaves and optionally repair remaining out-of-range notes without changing the source MIDI. Review every track individually; one global transpose is not always the best solution for a full orchestra.

## Troubleshooting keyboard problems

| Symptom | Check |
|---|---|
| Progress advances, no sound | ARM enabled, instrument equipped, expanded keyboard open, FFXIV Performance available |
| Wrong notes | Confirm the full 37-key setup and MIDI octave/transpose settings |
| Follower silent | Native Ensemble role, matching MIDI, assigned lanes and output ARM |
| “Performance not ready” | Open the 37-key keyboard; wait for instrument switch to settle |
| A song starts halfway through | Right-click the progress bar → **Reset MIDI to start (00:00)** |

**Next:** [[Your First Performance|Your-First-Performance]] · [[FFXIV Optimiser|FFXIV-Optimiser-and-MIDI-Tags]]
