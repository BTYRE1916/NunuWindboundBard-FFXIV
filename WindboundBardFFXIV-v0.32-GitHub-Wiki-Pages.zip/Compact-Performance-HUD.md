# Compact Performance HUD

[← Home](Home)

Windbound has a small **per-game-client** window for solo playing, multibox octets and concert monitoring. It is separate from the main player and can be shown while the main window is closed.

## Open the HUD

Type `/windbound hud` to toggle it, `/windbound hud show` to display it, or `/windbound hud hide` to dismiss it. You can also use **Show Performance HUD** in the main player.

## What it shows

- The logged-in **character name** and player role (Solo/Conductor/Follower).
- Current MIDI title and progress, elapsed/duration and basic status.
- ARM state, whether the 37-key Performance window is ready, and key playback controls.
- In expanded mode: instrument, current playlist, next song and detailed status.
- During conductor preparation: **READY X/Y** follow-up acknowledgements where available.

## Controls by role

| Role | HUD controls |
|---|---|
| **Solo** | Play, Pause/Resume, Stop, Next, ARM, Full player |
| **Conductor** | Play Ensemble/Ready Check, Stop, ARM, Full player |
| **Follower** | Monitoring, ARM, Stop and Full player; no independent Play button |

Right-click the HUD progress bar to reset the MIDI **locally**. For an ensemble, send a fresh conductor cue rather than rewinding only one Bard during a show.

## Customise appearance

- Drag the title bar to reposition the HUD.
- Switch between **Compact** and **Expanded** modes.
- Use **Lock** to prevent accidental movement.
- Adjust **Opacity** and optionally display the next song.
- Click **Full player** to open the main Windbound window.

Display choices are saved between sessions. ARM state is not.

## Multi-account note

Each FFXIV process renders **its own HUD** inside its game client. A follower HUD will not become a universal desktop overlay on top of seven other client windows. The **conductor** can still control the overall native ensemble and check acknowledgements from one client.

**Next:** [[Conductor & Octets|Conductor-and-Octet-Operations]] · [[Commands|Commands-and-Shortcuts]]
