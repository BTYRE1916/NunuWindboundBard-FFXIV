# Installation & Setup

[← Home](Home)

## Requirements

- A working installation of **Final Fantasy XIV** and a compatible **Dalamud** environment. After major FFXIV patches, allow Dalamud and the game's native interfaces to become compatible before testing.
- The Windbound Bard **compiled DLL and its dependencies**, or the source project and the tools needed to build it.
- For building the v0.32 source: **.NET 10**, **Dalamud.NET.Sdk 15**, and a suitable x64 build environment (the supplied project specifies `Dalamud.NET.Sdk/15.0.0`).
- A MIDI file in **Standard MIDI File** format (`.mid` or `.midi`, format 0 or 1).
- An FFXIV Performance-capable character and an expanded **37-note** Performance keyboard for sending game notes.

Optional additions: a local `.sf2` SoundFont for speaker preview, a USB MIDI controller for Live MIDI Piano, or the separate **vnavmesh** plugin on each client using saved stage navigation.

## Installing a compiled/test build

If the project maintainer supplies a **compiled** Windbound release or a maintained Dalamud plugin repository, follow the instructions for **that specific release**. Do not assume a GitHub source ZIP is an installable DLL or that an older repository manifest contains v0.32.

For a developer build, use Dalamud's official **Dev Plugin Locations** feature:

1. Start FFXIV through your Dalamud-enabled launcher.
2. Open `/xlsettings` → **Experimental** → **Dev Plugin Locations**.
3. Add the folder containing the built `NunuWindboundBard.dll` and its adjacent dependency files, or select the DLL where supported.
4. Apply the settings and load/enable the development plugin.
5. In FFXIV chat, enter **`/windbound`** to open the main window.

See [Dalamud's official Getting Started page](https://dalamud.dev/faq/getting-started/) for development-plugin instructions. The old `devPlugins` drop-in folder is no longer the recommended approach.

## Building from the Visual Studio source ZIP

1. Extract the complete project ZIP to a writable folder; don't open files directly inside the ZIP.
2. Open `NunuWindboundBard.sln` in Visual Studio, or use PowerShell in the extracted root:

   ```powershell
   .\Build-Plugin.ps1
   ```

3. The script builds **Debug/x64**. Resolve any package-restore or SDK errors reported by Visual Studio.
4. Confirm `NunuWindboundBard.dll` and the audio dependencies are in the output folder. The source project references **MeltySynth 2.4.1** and **NAudio 2.2.1**; deployment may require `MeltySynth.dll`, `NAudio.dll`, `NAudio.Core.dll`, and `NAudio.WinMM.dll` beside the plugin.
5. Add the built plugin folder under Dalamud **Dev Plugin Locations**. Launch or hot-reload, then open `/windbound`.

**Important:** A successful .NET build confirms compilation, not compatibility with the latest game client. Verify in game using the calibration MIDI.

## First-run choices

1. Open **Songs & Playback** and make sure a Solo performance is selected on the **Ensemble** tab.
2. Choose **English**, **Français**, or **Deutsch** from the language selector at the top.
3. Open **Direct Output & Test** and check the Performance mapping.
4. Open the full FFXIV Performance keyboard and follow [[First Performance|Your-First-Performance]].

## Where settings live

Windbound uses Dalamud's saved plugin configuration. MIDI paths and many settings are **per file or per client**, while **ARM state is intentionally not restored** after restarting. Back up the relevant Dalamud plugin configuration directory before upgrading to a beta, and save exported **Concert Snapshots** separately if you want portable copies of your setlists. Your SoundFont and MIDI files are **not** packaged inside configuration backups.

## Multiple accounts and Linux

Each running game client has its own plugin state and HUD. Native **FFXIV party commands** let clients on the same PC or different PCs coordinate without comparing local Windows timers. The older local shared-memory and private-TCP modes are available but are **not necessary** for recommended native ensemble operation.

The main MIDI engine has been exercised with testers on Windows and Linux/Wine. A physical MIDI controller or SoundFont audio backend on Linux depends on whether those Windows audio/MIDI APIs are exposed through Wine/Proton. Do not assume every audio device will be detected automatically.

## Support and updates

- Prefer a tested release over a new experimental build during a concert.
- Keep the previous ZIP/project and a copy of plugin configuration before each upgrade.
- After an FFXIV maintenance update, check native Performance, instrument switching, Ready Check and vnavmesh separately.
- If a UI label differs from this guide, compare the installed version against the v0.32 wiki target.

**Next:** [[Your First Performance|Your-First-Performance]] · [[Troubleshooting|Troubleshooting]]
