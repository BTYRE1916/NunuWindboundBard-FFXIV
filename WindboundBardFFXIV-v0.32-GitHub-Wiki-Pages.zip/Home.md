# Nunu's Windbound Bard FFXIV — Official User Wiki

**A MIDI performance and concert-management suite for Final Fantasy XIV**  
**Documentation version:** v0.32.0.0 (Dalamud API 15 / .NET 10)  
**Audience:** New performers, solo players, duet partners, octet conductors, and beta testers.

Welcome to the Windbound Bard wiki! Whether you want to play a single MIDI on one Bard or coordinate an eight-character concert, this manual takes you from your first 37-key test note to full-stage preparation.

> **Beta-build note:** These instructions are grounded in the **v0.32 source package**, not a promise that every feature is guaranteed after an FFXIV patch. Verify your installed plugin version; some menu names are translated in French/German. Certain features are experimental or require another Dalamud plugin. This is an unofficial third-party project.

## Start here

| I want to… | Read |
|---|---|
| Install or build the plugin | [[Installation & Setup|Installation-and-Setup]] |
| Play my first song | [[First Performance|Your-First-Performance]] |
| Set the 37-note keyboard correctly | [[Keyboard & Note Mapping|Performance-Keyboard-and-Mapping]] |
| Manage a MIDI library | [[Smart Playlists|Smart-Playlists]] |
| Perform an FFXIV duet or octet | [[Native Ensemble Quick Start|Native-Ensemble-Quick-Start]] |
| Control everyone's tracks and instruments | [[Conductor & Octets|Conductor-and-Octet-Operations]] |
| Prepare a full concert | [[Concert Director|Concert-Director-and-Setlists]] |
| Place performers on stage | [[Stage Formations|Visual-Stage-Designer]] |
| Save and reload a concert | [[Concert Snapshots|Concert-Snapshots-and-Restore]] |
| Hear a MIDI through speakers | [[SoundFont Preview|SoundFont-Audio-Preview]] |
| Play a USB MIDI piano live | [[Live MIDI Input|Live-MIDI-Piano]] |
| Fix errors or stuck playback | [[Troubleshooting|Troubleshooting]] |

## Main features

- **Direct FFXIV Performance output:** C3–C6 (37 notes), chord handling, octave adaptation, and safe in-game note callbacks rather than simulated typing.
- **Native ensemble:** conductor/follower roles, in-game Ready Check start, auto-accept, party file selection, track assignments, instrument switching, ARM ALL, and group STOP/unequip.
- **Concert tools:** Stage Manager, setlist preparation, individual-Bard retry, MIDI Inspector, snapshots, persistent octet lineups, and compact HUD.
- **Creative tools:** Soulweaver Studio, SoundFont speaker preview, live MIDI controller input, guitar-tone overrides, and original-MIDI-preserving exports.
- **Localisation:** English, Français, Deutsch.

## What this plugin does *not* do

Windbound cannot create missing MIDI files on another PC through ordinary party-chat selection. Native Ensemble START depends on the current FFXIV client and Dalamud compatibility. SoundFont preview is a **local audio playback** feature, not a recording or FFXIV soundfont emulator. Stage navigation uses optional vnavmesh and **walks**, rather than teleporting. The experimental stage diagram does **not** automatically rotate all Bards to face the audience.

## Recommended first-session order

1. [[Install|Installation-and-Setup]] Windbound and check the Dalamud version.
2. [[Configure the expanded 37-key Performance keyboard|Performance-Keyboard-and-Mapping]].
3. [[Play the bundled calibration MIDI|Your-First-Performance]] in Solo mode.
4. Only after Solo works, [[try two-account native ensemble|Native-Ensemble-Quick-Start]].
5. Then [[add the conductor controls|Conductor-and-Octet-Operations]] and [[Concert Director|Concert-Director-and-Setlists]].

## Navigation

Use the wiki sidebar for detailed chapters. The complete single-file manual and offline HTML edition are included in the documentation download. Your own `Config.json`, MIDI files, SoundFonts, and saved snapshot JSON files should be backed up independently of this wiki.

---
*Windbound Bard is a community/beta project for performers. Follow FFXIV's rules and respect music rights. No affiliation with Square Enix or the Dalamud developers is claimed.*
