**Nunu's Windbound Bard**  
*Wiki — v0.32*

**Getting started**
- [[Home]]
- [[Installation|Installation-and-Setup]]
- [[Your First Performance|Your-First-Performance]]
- [[37-Key Mapping|Performance-Keyboard-and-Mapping]]
- [[Commands|Commands-and-Shortcuts]]

**MIDI & rehearsal**
- [[Solo / Optimiser|FFXIV-Optimiser-and-MIDI-Tags]]
- [[Smart Playlists|Smart-Playlists]]
- [[MIDI Inspector|MIDI-Inspector]]
- [[Soulweaver Studio|Soulweaver-Studio]]
- [[SoundFont Audio Preview|SoundFont-Audio-Preview]]
- [[Live MIDI Piano|Live-MIDI-Piano]]

**Ensembles & concerts**
- [[Native Ensemble Quick Start|Native-Ensemble-Quick-Start]]
- [[Conductor & Octets|Conductor-and-Octet-Operations]]
- [[Octet Concert Checklist|Octet-Concert-Checklist]]
- [[Concert Director|Concert-Director-and-Setlists]]
- [[Stage Designer|Visual-Stage-Designer]]
- [[Concert Snapshots|Concert-Snapshots-and-Restore]]
- [[Performance HUD|Compact-Performance-HUD]]

**Reference & support**
- [[Languages|Languages-and-Localisation]]
- [[Troubleshooting|Troubleshooting]]
- [[FAQ|Frequently-Asked-Questions]]
- [[Build & Beta Testing|Build-Beta-Testing-and-Updates]]
- [[Version Reference|Version-and-Feature-Reference]]
- [[Glossary]]
