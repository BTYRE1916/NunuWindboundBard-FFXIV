# Your First Performance — Solo Quick Start

[← Home](Home)

This walkthrough is for a **single Bard**, with no party or conductor required. Complete it before trying octet synchronisation.

## Five-minute checklist

1. Type **`/windbound`** in FFXIV chat.
2. Open **Ensemble** and choose **Solo**.
3. Open **Songs & Playback**, then click **Load sample** to load the bundled `Bard-37-Note-Calibration.mid`. Alternatively click **Browse MIDI…** and select a `.mid` or `.midi` file.
4. Open **Instruments**. Choose a Performance instrument such as Piano or Lute. For an automatic switch, enable **Automatically switch instrument before Play**. If FFXIV doesn't open the Performance keyboard on its own, enter expanded Performance manually.
5. Ensure FFXIV's **expanded 37-key** Performance window is ready. Windbound should show a ready indicator.
6. In **Songs & Playback**, tick **ARM: Direct FFXIV Performance notes**.
7. Optionally open **Direct Output & Test** and click **Test C4**.
8. Click **Play**. Verify notes are audible and the progress bar advances from 0%.
9. Click **STOP** to stop. Use **Reset MIDI to start (00:00)** (or right-click the progress bar) to rewind.

> **ARM is a safety switch.** Without ARM, the player may run as a preview of scheduling without sending notes into FFXIV. ARM is not saved across plugin restarts.

## Main playback controls

| Control | Purpose |
|---|---|
| **Play** | Start the currently prepared MIDI; may first request the selected instrument |
| **Pause / Resume** | Pause or resume local Solo playback |
| **STOP** | Stop MIDI playback and release scheduled notes |
| **Next** | Move to the next song in the active Solo playlist |
| **Playback speed** | Adjust playback speed, 0.5×–2× |
| **Auto next** | Advance automatically when a Solo song finishes |
| **Reset MIDI to start** | Stop and rewind the local MIDI to 00:00 |
| **Show piano roll** | Show a visual lane/note preview in the player |
| **Show Performance HUD** | Open the compact, movable performance panel |

## Working with MIDI files

Windbound supports Standard MIDI Files of format **0** and **1**, including multi-track files. In Songs & Playback you can **Browse MIDI**, load a typed file path, add several files, or import a whole folder with optional subfolders. After a song loads, Windbound displays its track count, initial BPM, duration, final note count, chord groups and optimiser statistics.

If the notes sound too high/low, adjust the relevant **track octave** by `-12` or `+12` in Songs & Playback or the **FFXIV Optimiser** tab. A MIDI containing explicit `#+12`, `#-12`, `#Lute` or similar metadata can set these defaults automatically; see [[MIDI Instruments and Tags|FFXIV-Optimiser-and-MIDI-Tags]].

## About chords

The default **Full chords / original timing** mode preserves note start times and durations. Other reduction modes (melody/highest, lowest, loudest and gentle arpeggio) are helpful when dense chords do not sound cleanly through the game. FFXIV may limit the number or duration of simultaneous notes; hearing every note is not guaranteed simply because the plugin sent callbacks.

## If nothing plays

Before changing Windows or Linux keyboard settings, check: full Performance UI, ARM, a nonempty arrangement, the selected track checkboxes, and the **Instruments** status. If playback is stuck, try **`/windbound recover`**; it is an emergency local reset and requires ARM again. See [[Troubleshooting|Troubleshooting]].

**Next:** [[Smart Playlists|Smart-Playlists]] · [[Audio Preview|SoundFont-Audio-Preview]]
