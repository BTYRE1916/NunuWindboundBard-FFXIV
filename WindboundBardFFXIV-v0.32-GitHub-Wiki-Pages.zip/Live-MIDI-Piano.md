# Live MIDI Piano — Play a USB Keyboard in FFXIV

[← Home](Home)

**Live MIDI Piano** turns a physical MIDI keyboard or synthesizer into a live FFXIV Performance controller. This is a separate, **Solo-only** input path, not a MIDI file player or group conductor feature.

## Set up a keyboard

1. Connect the USB MIDI keyboard or MIDI interface to the PC.
2. In Windbound's **Ensemble** tab, choose **Solo**.
3. Open **Live MIDI Piano**.
4. Enable **Enable live MIDI controller input** and click **Refresh MIDI devices**.
5. Choose the MIDI port from the **MIDI input device** list.
6. Click **Connect keyboard**. The status should show the connected device name.
7. Click **Equip FFXIV Piano (instrument 2)** if needed. Open the **expanded 37-key Performance** interface.
8. Tick **ARM live notes to FFXIV** and play a few notes on the physical keyboard.

A MIDI file does **not** need to be loaded for live piano input.

## Live settings

| Setting | Purpose |
|---|---|
| **Controller octave transpose** | Shift incoming pitches by ±12-step octave increments (up to ±48) |
| **Fold other octaves into C3–C6** | Bring notes from an 88-key controller into FFXIV's limited range |
| **Use sustain pedal (CC64)** | Interpret a typical MIDI sustain pedal |
| **MIDI channel** | All channels (omni) or one selected channel |
| **PANIC: All Notes Off** | Release the router's held notes immediately |
| **Reconnect / Disconnect** | Recover from a disconnected or occupied MIDI device |

## Safety and limitations

- The live input router pauses itself while **MIDI-file playback is running**, to prevent two sources fighting over FFXIV keys.
- Turning ARM off, disconnecting, leaving Performance or switching to Ensemble stops/renders the live notes inactive.
- FFXIV's Performance interface accepts **C3–C6**; velocity and fully expressive piano dynamics aren't available through the game's 37-key callbacks.
- The input service uses **Windows WinMM**. Some controllers work through Wine; others require driver configuration or may be in use by another application.
- If notes become stuck, press **PANIC** or type `/windbound midipanic`.

## Diagnose a quiet keyboard

Check the **Connected** label, total **Received notes**, **Held notes**, **Last MIDI note**, **Bard note**, **Out-of-range** count and driver errors. If the plugin receives notes but FFXIV is quiet, check output ARM, Performance mode, C3–C6 mapping and instrument selection before reinstalling drivers.

**Next:** [[Keyboard Mapping|Performance-Keyboard-and-Mapping]] · [[Troubleshooting|Troubleshooting]]
