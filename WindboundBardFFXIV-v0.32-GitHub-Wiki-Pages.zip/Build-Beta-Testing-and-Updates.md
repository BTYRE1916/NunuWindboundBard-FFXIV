# Building, Beta Testing, Backups & Game Updates

[← Home](Home)

## Build checklist (v0.32)

- Source project: `NunuWindboundBard.sln`.
- SDK: **Dalamud.NET.Sdk 15.0.0**, **.NET 10**, `x64` target.
- Managed audio dependencies in `.csproj`: **MeltySynth 2.4.1**, **NAudio 2.2.1**.
- Build from the extracted project root with:

  ```powershell
  .\Build-Plugin.ps1
  ```

- The script builds `Debug` x64 and lists the output DLL; use `/xlsettings` → **Experimental** → **Dev Plugin Locations** to load the folder/DLL.
- Keep adjacent NuGet audio DLLs when distributing a compiled test build. A **source ZIP is not itself a compiled plugin**.
- Never swap unrelated `.cs` files from older versions into a new build; many source files evolved together.

## Recommended beta-test matrix

| Test | One client | Two Bards | Octet | Windows/Linux |
|---|:---:|:---:|:---:|:---:|
| Plugin loads, commands, translations | ✓ | | | ✓ |
| 37-key test C4, calibration MIDI | ✓ | | | ✓ |
| Polyphonic note + chord test | ✓ | | | ✓ |
| Instrument select / stow | ✓ | ✓ | | ✓ |
| MIDI fingerprint / file sync | | ✓ | ✓ | ✓ |
| SET PARTY TRACKS / INSTRUMENTS | | ✓ | ✓ | ✓ |
| ARM ALL / native Ready Check START | | ✓ | ✓ | ✓ |
| Concert Director PREPARE / Retry | | ✓ | ✓ | ✓ |
| SoundFont preview | ✓ | | | Device-specific |
| Stage navigation / visual dots | | ✓ | ✓ | vnavmesh-dependent |
| Live MIDI controller input | ✓ | | | WinMM-dependent |
| Snapshot export/import | ✓ | | | File-path-dependent |

Start with the smallest safe rehearsal before running an eight-account concert. For language feedback, ask native French/German users to check long or clipped strings, and verify they can still use the same commands.

## Reporting a bug

A useful report includes:

1. Windbound version and FFXIV/Dalamud build after the latest patch.
2. Windows or Linux/Wine/Proton and whether the issue happens on one or several clients.
3. Solo / Conductor / Follower role and in-game party size.
4. The exact steps and error text, including whether the **37-key** keyboard is open.
5. Which MIDI sample was used, or (if allowed to share) the failing MIDI file.
6. The most relevant **Copy diagnostics** report from [[Troubleshooting|Troubleshooting]].
7. A screenshot if the issue is visual (never include passwords or sensitive chat information).

## Back up before upgrading

Keep a versioned backup folder on your PC, for example:

```text
Windbound Backups/
  v0.31.2-known-working/
  v0.32-german-beta/
  Config-backup-YYYY-MM-DD/
  Concert-Snapshots/
  MIDI-Library/
  SoundFonts/
```

Keep the old source ZIP, the compiled plugin that worked, the Dalamud plugin configuration, exported Concert Snapshot JSON files and the actual MIDI files. A code ZIP alone does **not** preserve your custom character/track assignments if those settings live in Dalamud configuration.

## After an FFXIV patch

1. Wait for a compatible Dalamud build; don't assume native hooks survive maintenance.
2. Check that Windbound loads without signature errors.
3. Test **Solo** calibration and chords first.
4. Test instrument switching, full 37-key Performance UI and native START with two accounts.
5. Then check group STOP/unequip, Stage Manager and Stage Formations (including vnavmesh compatibility).
6. If something breaks, stop using that feature and keep a known-good build for comparison. Don't delete your saved lineups and snapshots as the first fix.

Useful references: [Dalamud Getting Started](https://dalamud.dev/faq/getting-started/), [Dalamud troubleshooting](https://goatcorp.github.io/faq/dalamud_troubleshooting.html), and [vnavmesh source](https://github.com/awgil/ffxiv_navmesh).

## Attribution and project boundaries

Windbound is an independent FFXIV performance plugin. Some ensemble behaviours are inspired by MidiBard 2's public workflow; this wiki does not claim MidiBard's code or branding. Any features using FFXIV native internals or other plugins can be affected by game patches. Respect the game's current terms and music-performance restrictions.

**Next:** [[Troubleshooting|Troubleshooting]] · [[Release Reference|Version-and-Feature-Reference]]
