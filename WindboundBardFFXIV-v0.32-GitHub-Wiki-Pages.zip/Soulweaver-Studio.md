# Soulweaver Studio — Create Solo, Duet, Quartet & Octet Arrangements

[← Home](Home)

Soulweaver is Windbound's arrangement generator. It analyses a loaded MIDI and creates separate musician parts for FFXIV Performance, using heuristic melody, bass and harmony grouping. It is **not** a generative audio model or a guarantee of perfect orchestration; audition and refine the results.

## Create an arrangement

1. Load the source MIDI in **Songs & Playback**.
2. Review and adjust octave shifts in **FFXIV Optimiser** if necessary.
3. Open **Soulweaver Studio**.
4. Select **Solo**, **Duet**, **Quartet** or **Octet** (1, 2, 4 or 8 performers).
5. Decide whether to **Analyse all non-percussion tracks** or respect the currently muted/enabled lanes.
6. Optionally set a **Per-performer chord limit**; `0` allows unlimited prepared chord notes.
7. Click **Analyse & Generate Parts**.
8. Examine the estimated key, generated note counts, range, warnings, timeline and per-part role descriptions.
9. For each generated part, choose its **FFXIV instrument** and, if applicable, a **party member**. The Auto-assign button uses party order.
10. Click **Export arrangement MIDI...** or **Export & add to Solo/Ensemble playlist**.

## Generated output

The exported MIDI is a **new file**; the original source is not overwritten. Each musician receives their own output track/lane, with original tempo changes preserved where possible. The file can then be loaded back into Windbound for native Ensemble preparation, SoundFont preview or inspection.

## Rehearsal workflow

- Use [[SoundFont Audio Preview|SoundFont-Audio-Preview]] in **Windbound Arrangement** mode to listen without sending FFXIV notes.
- Use [[MIDI Inspector|MIDI-Inspector]] to catch out-of-range notes, missing playable parts and conflicts.
- Use the **Party-Roster Track Assignments** panel to verify each Bard is responsible for the intended output lane.
- If the arrangement is too dense, reduce the chord limit or adjust melody/bass allocations; don't assume every MIDI sounds good in full chords.

## Saving and rerunning

Soulweaver presets are saved per source MIDI. If you change octave settings, regenerate the arrangement before exporting. A previously exported MIDI doesn't automatically change just because its source preset changed.

## Limitations

Soulweaver uses deterministic musical heuristics and cannot guarantee the desired lead melody, drum handling or instrument blend. Automatic instrument suggestions should be reviewed before equipping performers. Remember the game only supports a limited C3–C6 range and sometimes restricts audible polyphony.

**Next:** [[Inspector|MIDI-Inspector]] · [[Conductor & Octet|Conductor-and-Octet-Operations]]
