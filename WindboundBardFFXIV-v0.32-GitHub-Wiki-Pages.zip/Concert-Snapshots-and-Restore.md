# Concert Snapshots & Restore

[← Home](Home)

A **Concert Snapshot** is a named backup of a concert's configuration. You can save a Solo programme, duet, quartet, or full octet and restore it later without manually rebuilding every track or instrument selection.

## What's included

Snapshots can capture the active playlist and order, selected MIDI, per-file instrument and octave settings, track assignments, default octet lineup, playback tempo/settings, Smart Playlist details, Concert Director cues, and related rehearsal preferences. **They do not contain the MIDI audio bytes or SoundFont file itself.**

## Save a snapshot

1. Open `/windbound` → **Concert Snapshots**.
2. Type a useful name such as `Full Octet – Mist Stage – Friday`.
3. Click **SAVE CURRENT CONCERT SNAPSHOT**.
4. Verify it appears in the **Saved concert** drop-down with the correct number of MIDIs and performer slots.
5. For a PC backup, select it and click **Export snapshot JSON...**. Save the file somewhere outside the plugin folder.

## Restore a snapshot

1. Stop playback and any pending stage movement.
2. Go to **Concert Snapshots** and choose the saved entry.
3. Expand **Preview snapshot contents**. Check the selected MIDI, playlist name, performer slots and **Missing MIDI files** count.
4. Click **RESTORE SELECTED SNAPSHOT...** → **CONFIRM RESTORE**.
5. Windbound creates a **new saved playlist profile** and saves a **Before restore** safety snapshot.
6. Review the settings; ARM and follower consent are not restored.
7. For an ensemble, rejoin the correct party, **Prepare Entire Orchestra**, ARM everybody and send the normal native Ready Check.

**Restore is local and does not auto-start music, equip instruments, ARM output or broadcast party commands.** It can, however, replace some shared local per-MIDI override settings; review the automatically created Before restore backup if necessary.

## Import and export

- **Export snapshot JSON** stores data for backup/sharing, **not the MIDI files themselves**.
- **Import snapshot JSON** brings saved concert settings back to Windbound.
- On another computer, file paths may differ; add/copy the matching MIDI files locally and repair references as needed.
- Snapshots may include local path details and performer identifiers. Treat exported files as private to your ensemble.

## Recommended snapshot names

| Name | Use case |
|---|---|
| `Nunu Solo Piano` | Single Bard, piano settings and Solo playlist |
| `Edea Duet` | Piano/violin tracks, two-Bard order and instruments |
| `Full Octet – Main Set` | Eight-person track lineup and concert cues |
| `Festival Encore` | Special songs and a different prepared performer set |

**Next:** [[Concert Director|Concert-Director-and-Setlists]] · [[Backups & Updates|Build-Beta-Testing-and-Updates]]
