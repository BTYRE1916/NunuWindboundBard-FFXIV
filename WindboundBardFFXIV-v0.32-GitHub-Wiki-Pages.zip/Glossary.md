# Glossary

[← Home](Home)

| Term | Meaning in Windbound |
|---|---|
| **ARM** | Enables direct MIDI note output to FFXIV Performance; intentionally session-only |
| **Auto-Accept** | Option for an eligible follower to accept FFXIV's native Ensemble Ready Check automatically |
| **Bard lane** | A MIDI track/channel pairing that can be enabled, shifted and assigned independently |
| **Chord strategy** | How simultaneous MIDI notes are preserved, reduced or arpeggiated for Performance |
| **Conductor** | The party leader's plugin role used to prepare files, assignments, instruments and native START |
| **C3–C6** | The 37-note FFXIV Performance pitch span used by Windbound (MIDI 48–84) |
| **FFXIV Optimiser** | Track-by-track octave and dense-note adaptation without editing the original MIDI |
| **Follower** | Party client that accepts prepared parts, instrument changes and native START |
| **GM / General MIDI** | Standard MIDI instrument program assignments; SoundFont preview can render these patches |
| **HUD** | Compact per-client overlay for status and basic transport controls |
| **Native Ensemble START** | The game-origin FFXIV synchronisation event that begins ensemble playback |
| **Party fingerprint** | Compact hash/check used to match MIDI identity or roster state between conductor and followers |
| **PerformanceModeWide** | Expanded in-game Performance keyboard UI needed for the current 37-note output adapter |
| **Play Next** | Solo request queue separate from the saved playlist's normal order |
| **Snapshot** | Saved concert configuration and paths, but not the binary MIDI/SoundFont content |
| **Soulweaver** | Windbound's heuristic tool for generating Solo/Duet/Quartet/Octet arrangements |
| **SoundFont (.sf2)** | Sample bank used for local audio preview through a synthesiser |
| **Stage anchor** | Conductor's chosen reference point/heading for a saved stage formation |
| **vnavmesh** | Separate optional Dalamud plugin providing pathfinding/navigation for stage movement |
| **Wine/Proton** | Compatibility layers that may run FFXIV and some Windows-based plugin dependencies on Linux |

**Back to [[Home|Home]]**
