# MIDI Arrangement Inspector — Pre-Concert Quality Check

[← Home](Home)

The **MIDI Inspector** tab analyses the *currently prepared* MIDI, highlighting issues before you bring a party onto the stage. Inspection is read-only unless you explicitly ask Windbound to make an octave adjustment.

## Inspect an arrangement

1. Load the MIDI and any desired lane settings in **Songs & Playback**.
2. Open **MIDI Inspector**.
3. Click **INSPECT MIDI ARRANGEMENT**.
4. Review the summary: **playable notes / source notes**, errors, warnings, and per-lane pitch ranges.
5. Inspect each row for track/channel, current octave shift, suggested instrument, note count and party assignment.
6. Expand **Inspection findings** to see warnings such as out-of-range notes, suspicious overlaps or unused parts.
7. Click **Copy Inspection Report** to share a plain-text report with beta testers or your concert team.

## Auto-fit untagged octaves

**Auto-fit untagged octaves (manual action)** suggests in-range shifts for MIDI lanes that do **not** already have explicit `#+12`/`#-12` tags or saved manual octave overrides. This does not rewrite the original MIDI file. It also skips disabled tracks.

If you want the original file's tagged octave back, use the **MIDI Instruments & Octave Tags** controls in Songs & Playback rather than blindly changing everything.

## What to look for in an octet

| Finding | Action |
|---|---|
| Zero playable notes assigned to a Bard | Check track assignment and lane enable state |
| Many notes outside C3–C6 | Review octave shifts and repair options |
| Several tracks call for different instruments on one Bard | Choose a main instrument or split tracks |
| Excessive overlaps / duplicate pitches | Audition and consider chord-handling adjustments |
| Marked octave conflicts with manual shift | Confirm whether the manual override is intentional |
| Wrong inferred instrument | Check embedded MIDI metadata and saved instrument overrides |

## Exporting and audibly verifying

Inspect → edit lane settings → inspect again → [[Audio Preview|SoundFont-Audio-Preview]] → short Solo test → full Ensemble rehearsal. This is safer than trying a new dense MIDI live for the first time in front of an audience.

**Next:** [[FFXIV Optimiser|FFXIV-Optimiser-and-MIDI-Tags]] · [[Concert Director|Concert-Director-and-Setlists]]
