# Frequently Asked Questions

[← Home](Home)

### Can Windbound play an entire MIDI automatically?

Yes, in **Solo** mode it can play loaded MIDI notes through FFXIV's expanded Performance keyboard, after you ARM output. It does not synthesize audio inside the game by itself; the game Performance instrument is required.

### Can I run an octet on one PC?

The native party-based ensemble is designed for multibox parties and separate computers. Each FFXIV client needs the plugin configured as a Follower and must have the matching MIDI; the leader can sync files, instruments, tracks and ARM state from one conductor window.

### Does everyone need the exact same file path?

No. Native conductor file-sync uses a MIDI fingerprint to identify the matching local file. Everyone still needs the **actual MIDI bytes** on their computer; party chat does **not** transfer MIDI files.

### Will Windows and Linux Bards play together?

The main native ensemble/Performance features were tested on both systems during development. Third-party dependencies and the Windows-specific **Live MIDI Piano** and SoundFont audio backends may require Wine configuration. Each client also needs the right in-game 37-key Performance layout.

### Do followers have to click Ready Check?

With **Automatically accept FFXIV Ensemble Ready Check** enabled and the client ready, Windbound can accept automatically. The default is ON for new installs. It doesn't bypass a missing instrument, missing MIDI, wrong role or other readiness problem.

### Does ARM ALL actually start the song?

No. **ARM ALL** prepares note output. **START ENSEMBLE** separately uses FFXIV's native Ready Check and start event.

### Can I change which instrument a follower uses?

Yes. In the conductor's Ensemble panel, choose a per-Bard instrument and press **SET PARTY INSTRUMENTS**. Windbound can also infer instruments from MIDI track metadata when manual overrides don't take precedence.

### Can I keep my performer assignments between songs?

Yes. Enable **Keep party track assignments across songs** and save the default lineup. Special songs can have per-file overrides.

### Is the SoundFont preview audible to everyone in the party?

No. It is **local speaker playback only**, entirely separate from FFXIV Performance output and the ensemble start mechanism.

### Can I use an 88-key MIDI keyboard live?

Yes, with **Live MIDI Piano** in Solo mode. Notes outside C3–C6 can be folded into range, or skipped. The device must be accessible through the Windows MIDI input system/Wine equivalent.

### Can the stage dots move an entire party?

The conductor can design and save a formation then request movement for opted-in characters using optional **vnavmesh**. This walks, not teleports, and is experimental in v0.32. Auto-facing is not implemented.

### Will a snapshot include the MIDI files themselves?

No. Snapshots contain **configuration and paths**, not MIDI binary content, SoundFonts or secret connection codes. Save MIDI files separately.

### Can I switch language while performing?

The UI can switch between **English**, **Français** and **Deutsch** without a restart. It doesn't alter MIDI notes, party commands or performance timing. Avoid unnecessary UI interaction during a demanding live performance.

### Does “Stop” automatically unequip the whole party?

The **STOP ENSEMBLE + UNEQUIP ALL** conductor control requests that workflow. A local STOP or DISARM ALL action is different. The native stow request can fail if FFXIV refuses it; check the status instead of assuming it worked.

### Is this official or supported by Square Enix?

No. Windbound Bard is a third-party/beta plugin. Game updates can change native interfaces and unofficial plugin use may be against FFXIV's terms. Follow the game's rules and respect the rights of music creators.

**Next:** [[Home|Home]] · [[Troubleshooting|Troubleshooting]]
