# Stage Formations & Visual Stage Designer

[← Home](Home)

Windbound offers **saved stage positions** and an **experimental draggable dot editor**. These are two ways to create the same kind of formation preset.

> **Stage Designer is experimental and OFF by default in v0.32**, because v0.31 introduced a navigation/playback regression that was addressed in v0.31.1–0.31.2. First verify ordinary MIDI playback, then enable the visual editor for a controlled rehearsal.

## Prerequisites

- Same in-game FFXIV party, at the same actual stage and housing ward/instance.
- The actual party leader must select **Conductor**.
- Every participating character needs **vnavmesh** installed and working locally. Its navmesh needs to be ready for the area.
- Each Follower must enable **Allow my party leader to save my position and move me on stage**.
- All performers must be **out of Performance** and **out of combat** before movement.

Movement uses vnavmesh's normal path-walking. It does **not teleport** characters, bypass collision, or force a facing angle.

## Method A: Capture positions you've already placed

1. Position each Bard manually on the stage.
2. In the conductor's **Stage Formations** tab, enter a formation name.
3. Click **SAVE CURRENT PARTY POSITIONS**. Follower clients report their positions after their permission checks.
4. Select the saved preset in **Saved formations**.
5. During a later concert, return everyone to the correct stage/ward, then click **MOVE PARTY INTO SAVED FORMATION**.
6. Review arrival/failure results. Use **STOP STAGE MOVEMENT** to cancel navigation.

## Method B: Design a formation using dots

1. In **Stage Formations**, enable **Enable Visual Stage Designer (experimental)**.
2. Stand the conductor at approximately the stage centre and face toward your intended audience. Click **Re-anchor stage at my position** if the diagram's origin needs updating.
3. Create a diagram or load a saved formation.
4. Choose a starting shape — **Line**, **Arc**, **Circle**, or **Two Rows**.
5. Drag each numbered Bard dot around the square. The dot represents a position relative to the selected stage centre and heading.
6. Select a dot to assign the appropriate party member. Selecting someone already assigned swaps their spots, rather than duplicating a Bard.
7. Set the **Stage width (metres)**; optionally enable **Snap 0.5 m**.
8. Save the diagram without moving anyone, or click **SET POSITIONS & MOVE PARTY** to save and request movement.
9. Check acknowledgements, distances and failed path reports before preparing MIDI playback.

### Stage layout example

```text
   ┌──────────── STAGE (TOP VIEW) ────────────┐
   │       [4]   [5]   [6]   [7]             │
   │   [2]                          [8]       │
   │                [1]    [3]                │
   └──────────────────────────────────────────┘
                  AUDIENCE
```

This diagram is illustrative; the real layout is a draggable square inside Windbound. A dot is a **relative target**, not a guarantee that vnavmesh will find a walkable route.

## Safe operation

- **Same housing ward matters.** Different wards can have identical local coordinates; Windbound also checks that the party leader is actually nearby.
- **No automatic movement on login/song load.** The conductor explicitly clicks a move action.
- **No automatic facing in v0.32.** Facing is saved as a guide only.
- **No movement while playing or fighting.** Stop the MIDI and leave Performance before repositioning.
- If navigation becomes stuck, use **STOP STAGE MOVEMENT** or **`/windbound recover`** locally, then disable the experimental editor until tested.

## Common problems

| Problem | Suggested check |
|---|---|
| A Bard does not move | vnavmesh installed and its mesh built; follower stage permission enabled |
| Wrong stage/coordinates | All in same ward/instance; conductor re-anchor position/heading |
| Navigation times out | Dot may be unreachable; move it closer or change layout width |
| “Already running” or stuck state | Distinguish stage navigation from MIDI playback; stop stage movement and use recovery if needed |
| Facing incorrect | Auto-rotation isn't included in this version |

**Next:** [[Troubleshooting|Troubleshooting]] · [[Concert Director|Concert-Director-and-Setlists]]
