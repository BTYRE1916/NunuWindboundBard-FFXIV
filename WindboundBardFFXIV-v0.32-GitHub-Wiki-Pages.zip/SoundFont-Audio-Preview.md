# SoundFont Audio Preview (Local Speakers)

[← Home](Home)

SoundFont preview lets you hear a MIDI **through your local PC speakers** without equipping an FFXIV instrument or broadcasting notes to the party. It uses **MeltySynth** to render SoundFont instruments and **NAudio** for playback.

## What you'll need

- An existing `.mid` or `.midi` loaded in **Songs & Playback**.
- A General MIDI **`.sf2` SoundFont**. Windbound does not bundle any SF2 bank; choose one whose licence allows your intended use.
- Working Windows speaker output or suitable Wine/Proton audio compatibility; the v0.32 backend uses the Windows audio stack.

## Play a preview

1. Select and load a MIDI in **Songs & Playback**.
2. Open **Audio Preview**.
3. Click **Browse SoundFont...** and select an extracted `.sf2` file. You can also enter its path and click **Save SoundFont path**.
4. Choose **Preview source**:
   - **Original MIDI (all tracks and GM instruments)** — hear the original file, tempo changes and GM program information.
   - **Windbound C3–C6 arrangement (enabled local parts)** — hear notes after the current Windbound optimisations, lane mutes and octave shifts.
   - **Selected MIDI track (solo preview)** — listen to one lane; optionally **Apply this track's saved octave shift**.
5. Adjust **Preview volume** and **Preview tempo** (0.5×–2×).
6. Click **Play Audio Preview**. Use Pause/Resume and Stop Audio Preview normally.

## Which SoundFont should I use?

For a full band/octet with mixed instruments, choose a **complete GM SoundFont** with at least 128 GM melodic programs and percussion. Options to audition include [GeneralUser GS](https://schristiancollins.com/generaluser.php), [Arachno SoundFont](https://www.arachnosoft.com/main/soundfont.php) and FluidR3 GM where licensing permits. Different SoundFonts will render the same MIDI with different timbres.

> A SoundFont is a **speaker approximation**, not the exact timbre of FFXIV Performance instruments. Keep the original MIDI as a reference and audition the Windbound arrangement before a public concert.

## Common problems

| Symptom | Check |
|---|---|
| No audio | Selected `.sf2` exists, volume above zero, Windows default output device works |
| “SoundFont not found” | Extract the archive; select the **`.sf2` file**, not `.7z`/`.zip` |
| All parts sound like Piano | Original MIDI may contain few GM program changes; try Windbound arrangement mode and track metadata |
| Preview stops when pressing Play in FFXIV | Intentional safety behaviour: live FFXIV file playback stops local speaker preview |
| Compiler error about `MidiFileSequencer.MidiFile` | Use the corrected v0.27.1+ build; don't mix old Audio Preview files |
| Linux audio unavailable | Windows WinMM/NAudio backend may need Wine configuration; this path hasn't been proven universally |

**Next:** [[MIDI Inspector|MIDI-Inspector]] · [[Soulweaver Studio|Soulweaver-Studio]]
