# Concert Director, Stage Manager & Setlist Automation

[← Home](Home)

**Concert Director** is the conductor's rehearsal and live-show control centre. It sits in the **Ensemble** tab when native Game Ensemble and leader synchronisation are enabled.

## Prepare Entire Orchestra

1. Load the intended Ensemble MIDI.
2. Confirm performer slots, instrument choices and track assignments.
3. Click **PREPARE ENTIRE ORCHESTRA**.
4. Windbound runs the existing file/track/instrument preparation and requests status reports from the party.
5. Review **Stage READY: X/Y**. A yellow or missing row identifies a specific Bard who needs attention.
6. If one Bard fails, click **Retry** beside that member instead of resetting the other seven.
7. Once ready, click the separate **START ENSEMBLE** button to use FFXIV's native start mechanism.

Preparation **does not start music**. Song selection and instrument switching can occur before you address the audience.

## What a readiness report checks

Stage Manager can identify an invalid/missing MIDI, mismatched file fingerprint, absent track assignments, missing or wrong instrument, unready full Performance keyboard, output not ARMed, or unacknowledged follower state. These reports depend on party-chat delivery and can be refreshed. A message being sent is **not proof** every client received it; wait for each acknowledgement.

## Stage Manager buttons

| Control | Effect |
|---|---|
| **PREPARE ENTIRE ORCHESTRA** | Coordinate song, tracks and instrument preparation |
| **ARM ALL BARDS** | Enable output across participating clients (separate from START) |
| **Refresh Stage Status** | Request new status reports |
| **Retry** beside a Bard | Re-send preparation to that specific performer |
| **Cancel Preparation** | Cancel the current preparation cycle, not launch a song |
| **Copy Stage Report** | Copy a diagnostic summary to share with a tester |

## Concert Setlist Automation

Open the **Concert Setlist Automation** section in Concert Director.

- **Automatically prepare next Ensemble song (never auto-start)**: optional; **OFF by default**. Preloads the next MIDI and prepares the group after the current piece finishes. You still press native START for the next performance.
- **PREPARE NEXT SONG NOW**: manually stage the next song when you are ready.
- **Introduction / audience announcement**: a saved note for what you plan to say to your audience; treat it as a cue, not an automatic public-chat announcement.
- **Break after song (seconds)**: an intentional pause before the following preparation.
- **HOLD after this song**: pause the setlist workflow so you can speak, adjust instruments or take requests.
- **Mark as Encore**: annotate optional encore songs.

The next-song choice follows the Smart Playlist's saved order/Play Next logic; **the conductor remains in control of every native Ensemble START**.

## Example: Tenacious Bar'ds concert

| Order | Song | Concert cue | Action |
|---:|---|---|---|
| 1 | Opening Theme | Welcome the audience | Prepare orchestra, ARM, native START |
| 2 | Piano & Violin Duet | Introduce Edea | Prepare next; check two allocated parts |
| 3 | Full Octet | All eight players | Wait for 8/8 readiness; native START |
| 4 | Finale | Audience thanks | Mark as encore/HOLD after |

## Tips for a reliable show

- During a live concert, avoid enabling the experimental stage editor at the same time as active playback.
- Leave **Auto next** enabled only when you intend unattended **Solo** sequencing; ensembles are different.
- Use [[Concert Snapshots|Concert-Snapshots-and-Restore]] to preserve a complete show configuration.
- Keep **Audio Preview** local to avoid confusing rehearsal sound with game Performance output.
- Send a stage report if only some Bards become READY.

**Next:** [[Snapshots|Concert-Snapshots-and-Restore]] · [[Stage Designer|Visual-Stage-Designer]]
