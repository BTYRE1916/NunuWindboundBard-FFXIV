# Chat Commands & Controls Reference

[← Home](Home)

The commands below are verified in the **v0.32 `Plugin.cs` command handler**. Enter them in the FFXIV chat box.

| Command | Effect |
|---|---|
| `/windbound` | Open/close the main player window |
| `/windbound stop` | Stop local MIDI playback (when used as a conductor, follow the explicit group-STOP workflow for party-wide actions) |
| `/windbound recover` | Emergency reset of local MIDI scheduler/pending start/stage state; requires ARM again |
| `/windbound resetmidi` | Alias for local emergency recovery |
| `/windbound midipanic` | Live MIDI Piano: release all held controller notes |
| `/windbound hud` | Toggle Compact Performance HUD |
| `/windbound hud show` | Show the HUD |
| `/windbound hud hide` | Hide the HUD |

## Important UI actions that are **not** chat commands

- **SET PARTY TRACKS**, **SET PARTY INSTRUMENTS**, **ARM ALL BARDS**, **DISARM ALL** and **START ENSEMBLE** are buttons in the **Ensemble / Concert Director** interface.
- **STOP ENSEMBLE + UNEQUIP ALL** is the party-wide stop/put-away workflow; don't confuse it with simply closing a local HUD.
- **SET POSITIONS & MOVE PARTY** is in the **Stage Formations / Visual Stage Designer** area and does not start music.
- **Reset MIDI to start (00:00)** is also available via right-click on the playback progress bar; it rewinds only the local scheduler.

## Recommended keyboard/mouse shortcuts

Windbound doesn't need a global keyhook for MIDI playback. For fast work, leave the compact HUD movable/locked and use the on-screen controls. If your Windows keybindings or FFXIV Performance bindings differ from the supplied defaults, refer to [[Performance Keyboard & Mapping|Performance-Keyboard-and-Mapping]].

## After a failed command

Check the **status message** in the plugin rather than assuming the operation succeeded. Group commands must be received and acknowledged by the expected characters; one sent message is not delivery proof. See [[Troubleshooting|Troubleshooting]].
