# Native FFXIV Ensemble — Duet Quick Start

[← Home](Home)

**Recommended ensemble mode:** **FFXIV Native Ensemble Ready Check**. This uses FFXIV's in-game start mechanism. Windbound's retired party-chat time-delay start is not the recommended mode; ordinary party commands can prepare clients, but the **native game START** triggers the music.

## What every Bard needs

- The **same Windbound version** and a working Dalamud installation.
- Characters in the **same in-game FFXIV party**.
- Their own copy of the **exact MIDI** locally (file paths can differ by computer).
- An assigned musical part, the required instrument and the **expanded 37-key Performance** interface.
- Windbound's **ARM** enabled, either locally or via the conductor's **ARM ALL BARDS** control.

## Example: Nunu and Edea duet

### On the conductor's client

1. Open `/windbound` → **Ensemble** → select **Conductor**.
2. Enable **FFXIV native Game Ensemble** and **Automatically follow the party leader's MIDI and instrument choices** (leader sync).
3. Be the **actual FFXIV party leader**. Load the desired MIDI into the Ensemble playlist.
4. In **Party-Roster Track Assignments**, select which track/channel goes to Nunu and which goes to Edea.
5. Click **SET PARTY TRACKS** and confirm follower acknowledgements.
6. Select instruments and click **SET PARTY INSTRUMENTS** (or **PREPARE ENTIRE ORCHESTRA** in Concert Director).
7. Click **ARM ALL BARDS**. Wait for responses and check that both have their instruments and 37-key Performance keyboard ready.
8. Press **START ENSEMBLE — FFXIV Ready Check**. The game start cue triggers each client's assigned notes together.

### On Edea's follower client

1. Select **Follower** in Ensemble; enable **FFXIV native Game Ensemble**.
2. Leave **Automatically follow the party leader's MIDI and instrument choices** on.
3. Leave **Automatically accept FFXIV Ensemble Ready Check** on (this is enabled by default, but may be disabled manually).
4. Leave **Allow my party leader to ARM this Bard automatically** enabled if the conductor should operate ARM for this account.
5. The conductor's file and SET commands should load the matching local MIDI and prepare the selected tracks/instrument. Confirm the 37-key Performance UI is active.
6. Wait for the native START; the follower should not use its own Solo Play button.

## How song selection is synchronised

Windbound's conductor sends a **MIDI fingerprint and selection command**, not the MIDI file contents. A follower scans its local known MIDI entries for the matching file. If it cannot find the identical file, it reports an error: add the same MIDI to that client's library and retry.

## What Auto-Accept does

The auto-accept option can confirm an incoming **FFXIV Performance Ensemble Ready Check** when the client is configured and sufficiently ready. It is **not** a substitute for loading the right MIDI or entering Performance. If a client cannot participate safely, Windbound may refuse the check instead of pretending it is ready.

## Stop, disarm and unequip

- **STOP ENSEMBLE + UNEQUIP ALL**: conductor request to stop notes, close Performance and request the native instrument-stow action on all clients.
- **DISARM ALL**: turn output ARM off without necessarily putting instruments away.
- **STOP my playback**: local stop; not the same as conductor-wide group stop.

## Compatibility notes

Native Game Ensemble is designed for same-PC multiple game clients and parties across different machines, including mixed Windows/Linux setups. **Private TCP / Tailscale** is a separate legacy mode, not required for native FFXIV ensembles. Network party commands travel over normal **in-game party chat** and may be visible to party members; START timing itself comes from the game.

**Next:** [[Conductor & Octets|Conductor-and-Octet-Operations]] · [[Concert Director|Concert-Director-and-Setlists]]
