# FFXIV Optimiser, Instruments & MIDI Track Tags

[← Home](Home)

The optimiser adapts a MIDI to FFXIV's **C3–C6** Performance note range. It does this at playback time; the source `.mid` is not rewritten when you change a setting.

## Track-by-track settings

In **Songs & Playback** or **FFXIV Optimiser**, each MIDI track/channel appears as its own lane. You can:

- Enable or mute the lane.
- Shift it by octave steps (`-12`, `+12`) from **-48 to +48 semitones**.
- Enable **Repair remaining high/low notes by octaves**.
- Apply a **playback-only global transpose** of up to ±24 semitones.
- Choose full chords, highest/melody, lowest, loudest, or gentle arpeggio handling.
- Adjust minimum note gap, arpeggio spacing, and note hold duration.

Use the **MIDI Inspector** to see whether a shift actually improves the playable note count.

## Detecting instruments automatically

Windbound reads MIDI Program Change data and instrument metadata, including track names, instrument names, text and marker/cue events. When possible it recommends a matching FFXIV instrument; General MIDI programs without an exact equivalent are approximated. Turn on **Auto-detect instruments from MIDI tracks / GM programs** under **MIDI Instruments & Octave Tags**.

For a group, the conductor **assigns tracks to Bards first**. Then **SET PARTY INSTRUMENTS** uses detected instrument suggestions for the assigned tracks, unless a saved manual choice overrides them.

## Track-name notation

Windbound recognises explicit instrument and octave instructions such as:

```text
#+12 #Lute
#-12 #Piano
#Violin
#+24 #Flute
```

- `#+12` means **transpose that lane up one octave**; `#-12` means down one octave.
- `#Lute` selects/recommends the **FFXIV Lute** instrument.
- The tags affect **that track**, not the whole orchestra.
- A track containing both a tag and a General MIDI patch gives priority to the explicit tag.
- If a performer owns multiple conflicting instrument tracks, the conductor gets a suggestion/warning and should choose one instrument for that performer.

## Manual overrides and re-reading tags

Manual octave changes are saved per MIDI path and take precedence over subsequently imported tags. If a tag seems ignored, open **MIDI Instruments & Octave Tags** and try:

1. **Re-read MIDI tags now (keep manual overrides)** — rescans metadata without overriding your edits.
2. **Restore MIDI octave tags (clear manual octave overrides)** — clears saved manual octave settings for the current MIDI and reapplies tags.
3. **Use MIDI instrument suggestions (clear manual instrument overrides)** — tells the conductor to use detected instruments again.
4. **Copy detected MIDI metadata report** — provides raw labels, GM programs, tag values and actual applied octaves for troubleshooting.

Do not press reset buttons casually during a prepared concert if you need specific custom octaves; save a Concert Snapshot first.

## Guitar tone overrides

For an electric guitar instrument, open **Guitar Tones** and enable track-based overrides. Select Clean, Overdriven, Muted, Power Chords or Special (where applicable). Changes are remembered per MIDI/track/channel and applied on the next performance. FFXIV supports one active guitar tone per performer at a time, so simultaneous tone changes across multiple tracks may conflict.

## Useful sample files

- `Bard-37-Note-Calibration.mid` — basic pitch test.
- `Bard-Chord-Callback-Test.mid` — overlapping note and chord test.
- `Windbound-MIDI-Instrument-and-Octave-Tags.mid` — tagged instrument/octave test.
- `Windbound-MIDI-FF01-Marker-and-GM-Detection.mid` — metadata format test.

**Next:** [[MIDI Inspector|MIDI-Inspector]] · [[Ensemble|Native-Ensemble-Quick-Start]]
