# Version & Feature Reference

[← Home](Home)

This wiki targets **Windbound Bard v0.32.0.0**, the latest project source inspected for the documentation. Its release archive is a source package intended for compilation/testing, not a guarantee that an up-to-date binary is hosted at a particular website.

| Approx. version | Major feature introduced |
|---|---|
| v0.1–0.4 | Basic FFXIV MIDI and chord-aware direct Performance callbacks |
| v0.5–0.8 | Instruments, track octaves, same-PC party setups and saved playlists |
| v0.9–0.12 | Private TCP, song transitions, Soulweaver and early native ensemble support |
| v0.13–0.19 | Party-controlled starts and later MidiBard-style native Ready Check, file/track/instrument synchronisation |
| v0.20 | Live USB MIDI Piano; group native instrument-stow refinements |
| v0.21–0.22 | French UI; MIDI instrument/`#+12` tag detection |
| v0.23 | Persistent octet performer lineups |
| v0.24 | Concert Director, readiness monitoring and ensemble preparation |
| v0.25 | Automated setlist preparation (not automatic music START), targeted single-Bard retry |
| v0.26 | MIDI Arrangement Inspector |
| v0.27 / v0.27.1 | SoundFont speaker preview / compiler compatibility fix |
| v0.28 | Concert Snapshots & Restore |
| v0.29 | ARM ALL and DISARM ALL party controls |
| v0.30 | Saved stage positions with optional vnavmesh walking |
| v0.31 / .1 / .2 | Visual Stage Designer, local playback recovery and compiler fixes |
| **v0.32** | German interface translations alongside English and French |

## Current recommended feature configuration

- **For native ensemble:** conductor + followers, leader sync enabled, FFXIV native Ready Check, matching local MIDI file, 37-key Performance, and session ARM.
- **For Solo:** full keyboard, a loaded file, selected instrument, ARM, Play.
- **For stage dots:** after Solo and ensemble are confirmed stable, enable experimental Visual Stage Designer; install/configure vnavmesh separately.
- **For SoundFont preview:** load local `.sf2` and keep speaker preview separate from in-game notes.

## Where new instructions belong

When editing the plugin after v0.32, update the affected wiki page and this reference table. Keep a known-good screenshot of the UI and a tested key-mapping sample alongside each tagged release; avoid claiming a release is “stable” until it has passed a real in-game rehearsal.

**Next:** [[Home|Home]] · [[Beta Testing|Build-Beta-Testing-and-Updates]]
