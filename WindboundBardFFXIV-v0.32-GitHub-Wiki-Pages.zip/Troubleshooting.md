# Troubleshooting & Recovery

[← Home](Home)

This chapter focuses on problems observed during Windbound's development and beta tests. Always record the **exact displayed error** and plugin version before making large configuration changes.

## A. No sound / progress increases but Bard stays silent

1. Confirm the game is in **expanded 37-key Performance**, not mini mode.
2. Ensure **ARM** is checked.
3. Check that a Performance instrument is actually equipped and the game's Performance UI is READY.
4. Verify the MIDI has playable notes in **C3–C6**, and the track/channel is enabled.
5. Use **Direct Output & Test → Test C4** and the bundled calibration MIDI.
6. Check the instrument switcher's diagnostics if the equipment changed but the 37-key keyboard didn't open.

**Known tester finding:** A Linux client appeared silent until its FFXIV 37-key setup was corrected. That was a configuration issue, not evidence that Windbound generally fails on Linux.

## B. “Already running” / stuck playback

- Stop any active MIDI and stage movement.
- Type **`/windbound recover`**, or use **Songs & Playback → EMERGENCY: Reset stuck playback**.
- Allow one game update for held notes to release. ARM again manually.
- If FFXIV itself is still in a native Ensemble, end it through the game's UI; the plugin reset cannot override server state.
- Disable **Visual Stage Designer (experimental)** while confirming Solo playback works.
- Copy **Song switching diagnostics** if the error persists; distinguish MIDI scheduler state from vnavmesh's “Another stage movement is already running.”

## C. Conductor switches instrument locally but follower doesn't

- Check that both use the **same plugin build**.
- The sender must be the actual **FFXIV party leader**.
- Follower role, native Game Ensemble and **Automatically follow party leader's MIDI and instrument choices** must be enabled.
- Use **Party command receiver diagnostics** on the follower. Look for messages seen, accepted/rejected counts and a reason.
- If the command was accepted but no switch occurs, inspect **Instrument switching diagnostics**, not the party transport.
- A full plugin reload and reapplying follower options can clear stale runtime state, but save configuration before resets and don't rely on reloading as the only fix.

## D. Instrument equipped but 37-key UI isn't open

This is a distinct readiness problem. Wait for the switch state to settle, open the expanded Performance keyboard and check the ready indicator. The party may have selected the correct instrument while the UI is not yet usable. Use **Instruments → Switch to selected instrument NOW** for a local diagnostic.

## E. FFXIV native Ensemble fails to start everybody

- Don't use the retired **party-chat countdown** option; use **native FFXIV Ready Check**.
- Confirm all Bards have the **identical MIDI**, correct assigned lanes, instruments, ARM state and full Performance keyboard.
- On the conductor, run **Prepare Entire Orchestra** and **Refresh Stage Status**; resolve every missing/failed performer.
- Auto-Accept is on by default, but may be unchecked on a client. There is a manual confirm fallback under **Native Ensemble diagnostics / manual fallback**.
- If only one account is ready, verify party leader, role and receiver diagnostics; don't just spam START.

## F. Bad notes / misplaced octaves / wrong instruments

- Use the **MIDI Inspector** and inspect individual lane pitches.
- Check `#+12`, `#-12`, `#Lute` and General MIDI program data.
- Inspect **Copy detected MIDI metadata report** for applied vs detected octave.
- Saved manual overrides take priority. Use **Restore MIDI octave tags** or **Use MIDI instrument suggestions** only when you want to replace those overrides.

## G. SoundFont preview problems

- Select a real, extracted `.sf2` SoundFont, not a ZIP or SFZ file.
- Verify speaker output and preview volume.
- Remember this is **local audio only**, and FFXIV file playback stops preview automatically.
- If building from old source and seeing `MidiFileSequencer.MidiFile` CS1061, use the v0.27.1+ corrected source files.

## H. Stage-dot movement fails

- Confirm **vnavmesh** on every participating client and follower stage permission.
- Check same housing ward/instance, actual nearby party leader, and that everyone is idle/out of combat.
- Move the dot nearer or adjust stage width; a dot may fall inside an obstacle even if it fits on the 2D diagram.
- Use **STOP STAGE MOVEMENT** rather than letting a bad route run.
- In v0.32 the visual editor is **OFF by default** and automatic facing is not supported.

## I. Problems immediately after an FFXIV patch

A native hook, Dalamud build or vnavmesh dependency may need updating. Check version compatibility before reinstalling Windows drivers or deleting Windbound settings. Keep a previous known-good project build and a configuration/snapshot backup.

## Copying the right diagnostic report

| Problem | Copy report from |
|---|---|
| MIDI doesn't load | Songs & Playback → **Copy MIDI loading diagnostics** |
| MIDI transitions/stuck state | Songs & Playback → **Copy song switching diagnostics** |
| Instrument switch | Instruments → **Copy instrument diagnostics** |
| Party leader/follower command | Ensemble → **Copy party-command report** |
| Native start | Ensemble → **Copy native diagnostics** |
| Group preparation | Concert Director → **Copy Stage Report** |
| Octave/instrument tags | MIDI metadata → **Copy detected MIDI metadata report** |
| Arrangement quality | MIDI Inspector → **Copy Inspection Report** |

**Privacy:** Reports can include local filesystem paths, character names and party identifiers. Review the clipboard text before posting it publicly.

**Next:** [[Beta Testing|Build-Beta-Testing-and-Updates]] · [[Commands|Commands-and-Shortcuts]]
