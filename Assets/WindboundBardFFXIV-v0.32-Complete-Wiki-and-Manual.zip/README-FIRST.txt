NUNU'S WINDBOUND BARD FFXIV — WIKI & USER MANUAL
Documentation version: v0.32.0.0 / November 2026

START HERE
  1. Open the single-file "WindboundBardFFXIV-Complete-Manual.html" in your browser.
     Works offline; includes searchable chapter navigation.
  2. Or open "WindboundBardFFXIV-Complete-Manual.md" in any Markdown editor.
  3. For an actual GitHub Wiki, use the individual .md files in the "wiki" folder.

GITHUB WIKI PUBLICATION
  - Enable the Wiki feature for your repository on GitHub (if available).
  - Open the Wiki tab, create an initial Home page if necessary.
  - Clone its companion wiki repository (usually REPO.wiki.git).
  - Copy the .md files from this package's "wiki" directory to the wiki repository root.
  - Commit and push. GitHub Wiki uses Home.md, _Sidebar.md, and _Footer.md specially.
  - Do not upload this ZIP as a plugin binary; it contains documentation only.

DOCUMENTATION SCOPE
  - Grounded in the NunuWindboundBard v0.32.0.0 Visual Studio source package.
  - Written for Solo, Follower, Conductor and beta testers.
  - Certain experimental/native features require in-game revalidation after FFXIV patches.
  - The Visual Stage Designer is experimental and OFF by default in v0.32.
  - Snapshot backups store settings and paths, not MIDI files.

BEFORE SHARING
  - No personal passwords or MIDI files are included.
  - Source and URLs are documented, but the bundled tutorial is not a compiled DLL.
  - This is an unofficial third-party performance tool, not affiliated with Square Enix.
